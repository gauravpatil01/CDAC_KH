﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SecureWebAPI.Models;
using SecureWebAPI.Services;
using SecureWebAPI.Helper;

namespace SecureWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        IUserService _userService;
        public UsersController( IUserService userService) {
            _userService = userService;

        }

        [HttpPost("authenticate")]
        public IActionResult Validate(AuthenticateRequest model)
        {
            var response = _userService.Authenticate(model);
            if (response == null)
                return BadRequest(new { message = "Username or password is incorrect" });
            return Ok(response);
        }

        //Fully Qualified Name: SecureWebAPI.Helper.Authorize
        [Helper.Authorize]
        [HttpGet("allusers")]
        public IActionResult GetAll()
        {
            var users = _userService.GetAll();
            return Ok(users);
        }
    }
}
