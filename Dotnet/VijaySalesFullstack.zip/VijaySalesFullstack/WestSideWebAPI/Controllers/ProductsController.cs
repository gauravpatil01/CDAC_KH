﻿using Microsoft.AspNetCore.Mvc;
using  WestSideWebAPI.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WestSideWebAPI.Controllers
{

    //Each controller which inherited from ControllerBase class
    //is responsible for handling a specific set of HTTP requests.
    //processing the request,
    //interacting with the model, and
    //returning the json data  to client which is invoking remotely.

    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        // GET: api/<ProductsController>
        [HttpGet]
        public IEnumerable<Product> Get()
        {
            return new Product[] { 
                new Product { Id = 1, Name = "Gerbera", Description = "Wedding Flower", Price = 70 },
                new Product { Id = 2, Name = "Rose", Description = "Valentine Flower", Price = 12 },
                new Product { Id = 3, Name = "Lotus", Description = "Worship Flower", Price = 33 },
                new Product { Id = 4, Name = "Marigold", Description = "Festival Flower", Price = 49 },
                new Product { Id = 5, Name = "Jasmine", Description = "Fregrance Flower", Price = 45 }
            };
        }

        // GET api/<ProductsController>/5
        [HttpGet("{id}")]
        public Product Get(int id)
        {
            return new Product { Id = 1, Name = "Gerbera", Description = "Wedding Flower", Price = 70 };
        }

        // POST api/<ProductsController>
        [HttpPost]
        public void Post([FromBody] string value)
        {

        }

        // PUT api/<ProductsController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<ProductsController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
