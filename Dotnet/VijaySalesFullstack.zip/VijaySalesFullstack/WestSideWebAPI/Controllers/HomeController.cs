using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WestSideWebAPI.Models;

namespace WestSideWebAPI.Controllers
{

    //Each controller which inherited from Controller class
    //is responsible for handling a specific set of HTTP requests.
    //processing the request,
    //interacting with the model, and
    //returning the view to the browser.
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            var product = new { Id = 4, Name = "Marigold", Description = "Festival Flower", Price = 49 };
            return View();

        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
