

//asp.net core code with minimal code to run the server

using VijaySalesFullstack.Server.Entities;
using VijaySalesFullstack.Server.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

var app = builder.Build();

app.UseDefaultFiles();
app.MapStaticAssets();

// Configure the HTTP request pipeline.

var summaries = new[]
{
    "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
};



// REST API Endpoint Implementation for WeatherForecast, Products

app.MapGet("/weatherforecast", () =>
{
    var forecast = Enumerable.Range(1, 5).Select(index =>
        new WeatherForecast
        (
            DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
            Random.Shared.Next(-20, 55),
            summaries[Random.Shared.Next(summaries.Length)]
        ))
        .ToArray();
    return forecast;
});

app.MapGet("/api/products",() =>
{
    //annonymous type array of products objects
    ProductService svc = new ProductService();
    var products = svc.GetProducts();
    return products;
});

app.MapGet("/api/products/{id}", (int id) =>
{
    //annonymous type object of product
    var product = new { Id = 4, Name = "Marigold", Description = "Festival Flower", Price = 49 };
    return product;
});

app.MapPost("/api/products", (Product product) =>
{
    //returning the product object
    ProductService svc = new ProductService();
    var products = svc.AddProduct(product);
    return product;
});

app.MapDelete("/api/products/{id}", (int id) =>
{
    //returning the product object
    ProductService svc = new ProductService();
    var product = svc.DeleteProduct(id);

    return product;
});

app.MapPut("/api/products/{id}", (Product product, int id) =>
{
    //returning the product object
    ProductService svc = new ProductService();
    var products = svc.UpdateProduct(product);
    return product;
});


app.MapFallbackToFile("/index.html");

app.Run();

internal record WeatherForecast(DateOnly Date, int TemperatureC, string? Summary)
{
    public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);
}
