﻿using VijaySalesFullstack.Server.Entities;
namespace VijaySalesFullstack.Server.Services
{
    public class ProductService
    {
        public IEnumerable<Product> GetProducts()
        {
            return new[]
            {
                new Product { Id = 1, Name = "Gerbera", Description = "Wedding Flower", Price = 70 },
                new Product { Id = 2, Name = "Rose", Description = "Valentine Flower", Price = 12 },
                new Product { Id = 3, Name = "Lotus", Description = "Worship Flower", Price = 33 },
                new Product { Id = 4, Name = "Marigold", Description = "Festival Flower", Price = 49 },
                new Product { Id = 5, Name = "Jasmine", Description = "Fregrance Flower", Price = 45 },
            };
        }

        public Product GetProduct(int id)
        {
            return new Product { Id = 4, Name = "Marigold", Description = "Festival Flower", Price = 49 };
        }
        public bool AddProduct(Product product)
        {
            // insert product into database
            // invoke repository method

            return true;
        }
        public bool DeleteProduct(int id)
        {
            // delete product from database
            // invoke repository method
            return true;
        }

        public bool UpdateProduct(Product product)
        {
            // update product in database
            // invoke repository method
            return true;
        }
    }
}
