﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PaintBrush_GUI
{
    public partial class Form1 : Form
    {

        private Point startPoint = new Point(10, 10);
        private Point endPoint = new Point(100, 200);
        private int shape = 1;

        public Form1()
        {
            InitializeComponent();
        }

        private void OnPaint(object sender, PaintEventArgs e)
        {
            Graphics graphics = e.Graphics;    
            Pen pen = new Pen(Color.Red,3);

            switch (shape)
            {
                case 1:
                    graphics.DrawLine(pen, startPoint, endPoint);
                    break;
                case 2:
                    int width=endPoint.X-startPoint.X;
                    int height=endPoint.Y-startPoint.Y;
                    graphics.DrawRectangle(pen, startPoint.X, startPoint.Y,width, height );
                    break;
            }
            
        }

        private void OnMouseDown(object sender, MouseEventArgs e)
        {
           this.startPoint = new Point(e.X, e.Y);
        }

        private void OnMouseUp(object sender, MouseEventArgs e)
        {
           this.endPoint = new Point(e.X, e.Y);
           this.Invalidate();
        }

        private void lineToolStripMenuItem_Click(object sender, EventArgs e)
        {
            shape = 1;
        }

        private void rectangleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            shape = 2;
        }
    }
}
