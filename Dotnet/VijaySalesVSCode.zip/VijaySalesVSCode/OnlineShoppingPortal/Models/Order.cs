﻿namespace OnlineShoppingPortal.Models
{
    public class Order
    {
    }
}
