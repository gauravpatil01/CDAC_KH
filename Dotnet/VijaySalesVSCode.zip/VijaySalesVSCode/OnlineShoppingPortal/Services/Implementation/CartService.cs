﻿using OnlineShoppingPortal.Models;
using OnlineShoppingPortal.Services.Interfaces;

namespace OnlineShoppingPortal.Services.Implementation
{
    public class CartService : ICartService
    {
        public void AddToCart(int productId)
        {
            throw new NotImplementedException();
        }

        public void ClearCart()
        {
            throw new NotImplementedException();
        }

        public Cart GetCart()
        {
            throw new NotImplementedException();
        }

        public void RemoveFromCart(int productId)
        {
            throw new NotImplementedException();
        }
    }
}
