﻿namespace StateManagmentApp.Models
{
    public class CompanyData
    {
        public string Name { get; set; }
        public string FinancialYear { get; set; }
        public List<int> YearlyData { get;set; }    
    }
}
