﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace StateManagmentApp.Models
{
    
    public class Student
    {
        public int StudentId { get; set; }
        public string? Name { get; set; }
        public string? Branch { get; set; }
        public string? Section { get; set; }
        public string? Gender { get; set; }
    }
}
