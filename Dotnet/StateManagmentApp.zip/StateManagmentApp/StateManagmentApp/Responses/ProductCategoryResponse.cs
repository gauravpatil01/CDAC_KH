﻿namespace StateManagmentApp.Responses
{
    public class ProductCategoryResponse
    {
    }
}
